﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практ13
{
    internal class Program
    {
        static void Main(string[] args)
        {

            ArrayList list = new ArrayList();
            list.Add(4.5);
            list.Add(18); 
            list.AddRange(new string[] { "Студент", "Петров" }); 

            foreach (object e in list)
            {
                Console.WriteLine(e);
            }

            list.RemoveAt(0);
            list.Reverse();
            Console.WriteLine(list[1]);

            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }

            ArrayList list2 = new ArrayList();

            Console.WriteLine("Пишите элементы заносимые в list2, каждое с новой строки\n(при вводе значения отличного от int занесение будет прервано)\n(заносим int)");
            int j = 0;
            do
            {
                try
                {
                    list2.Add(Convert.ToInt64(Console.ReadLine()));
                    j += 1;
                }
                catch { Console.WriteLine("стоп"); 
                    j = -1; }
                
            }
            while (j != -1);

            Console.WriteLine("Введите количество элементов которые надо удалить");
            int del = Convert.ToInt32(Console.ReadLine());

            int n = Convert.ToInt32(list2[1]);

            if (del < list2.Count)
            {

                try
                {
                    list2.RemoveRange(n/2,del);
                }
                catch { Console.WriteLine("Элементы кончились раньше чем счётчик дошёл до введённого значения"); }

            }
            else { Console.WriteLine("Вы ввели значение больше размера списка"); }


            for (int i = 0; i < list2.Count; i++)
            {
                Console.WriteLine(list2[i]);
            }

            Console.ReadLine();

        }
    }
}
